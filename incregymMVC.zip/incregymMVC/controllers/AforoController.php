<?php

class AforoController
{
    public function index()
    {
        $title = "Aforo - IncreGym";
        $view = "views/aforo/index.php";
        include "views/layout.php";
    }
}