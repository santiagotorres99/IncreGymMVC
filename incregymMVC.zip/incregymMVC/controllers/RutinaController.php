<?php

class RutinaController
{
    public function index()
    {
        $title = "Rutinas - IncreGym";
        $view = "views/rutinas/index.php";
        include "views/layout.php";
    }
}