<?php
require_once __DIR__ . '/../models/Usuario.php';


class UsuarioController {
private $usuarios;


public function __construct() {
$this->usuarios = Usuario::all();
}


public function index() {
$title = 'Usuarios - IncreGym';
$view = __DIR__ . '/../views/usuarios/list.php';
include __DIR__ . '/../views/layout.php';
}


public function create() {
$title = 'Nuevo usuario';
$view = __DIR__ . '/../views/usuarios/create.php';
include __DIR__ . '/../views/layout.php';
}


public function store() {
header('Location: /incregymMVC/?url=usuarios');
exit;
}


public function show() {
$id = $_GET['id'] ?? 1;
$usuario = null;


foreach ($this->usuarios as $u)
if ($u['id'] == $id) $usuario = $u;


$title = 'Ficha usuario';
$view = __DIR__ . '/../views/usuarios/show.php';
include __DIR__ . '/../views/layout.php';
}
}
?>