<?php

class HorarioController
{
    public function index()
    {
        $title = "Horarios - IncreGym";
        $view = "views/horarios/index.php";
        include "views/layout.php";
    }
}