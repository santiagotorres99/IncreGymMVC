<?php
class HomeController {
public function index() {
$title = 'Inicio - IncreGym';
$view = __DIR__ . '/../views/home.php';
include __DIR__ . '/../views/layout.php';
}
}
?>