<div class="card p-4">
    <h2>Bienvenido, <?= $_SESSION['user'] ?> !</h2>
    <p class="mt-3">Hoy tienes:</p>
    <ul>
        <li>Zumba - 18:30</li>
        <li>Crossfit - 20:00</li>
    </ul>
</div>