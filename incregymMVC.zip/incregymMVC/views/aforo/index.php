<div class="card p-4">
    <h3 class="fw-bold">👥 Aforo</h3>
    <p class="text-muted">Control del aforo en tiempo real.</p>

    <div class="alert alert-danger mt-3">
        Podemos añadir:
        <ul>
            <li>Capacidad total</li>
            <li>Personas dentro</li>
            <li>Advertencias</li>
        </ul>
    </div>
</div>