<div class="card p-4">
    <h3 class="fw-bold">🕒 Horarios</h3>
    <p class="text-muted">Sección para gestionar y visualizar horarios de actividades.</p>

    <div class="alert alert-info mt-3">
        Aquí podremos cargar la tabla de horarios, actividades del día, filtros, etc.
    </div>
</div>