<div class="card p-4">
    <h3>Ficha del usuario</h3>
    <p><strong>Nombre:</strong> <?= $usuario['nombre'] ?></p>
    <p><strong>Email:</strong> <?= $usuario['email'] ?></p>
    <p><strong>Edad:</strong> <?= $usuario['edad'] ?></p>
    <a href="/incregymMVC/?url=usuarios" class="btn btn-primary">Volver</a>
</div>