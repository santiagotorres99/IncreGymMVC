<div class="card p-4">
    <h3>Crear usuario</h3>
    <form method="post" action="/incregymMVC/?url=usuarios/store" class="mt-3">
        <div class="mb-3">
            <label class="form-label">Nombre</label>
            <input name="nombre" class="form-control">
        </div>
        <div class="mb-3">
            <label class="form-label">Email</label>
            <input name="email" class="form-control">
        </div>
        <div class="mb-3">
            <label class="form-label">Edad</label>
            <input type="number" name="edad" class="form-control">
        </div>
        <button class="btn btn-success">Crear</button>
        <a href="/incregymMVC/?url=usuarios" class="btn btn-secondary">Cancelar</a>
    </form>
</div>