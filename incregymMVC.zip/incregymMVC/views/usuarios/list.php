<div class="card p-4">
    <h3>Lista de usuarios</h3>
    <table class="table table-striped mt-3">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Edad</th>
                <th>Email</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($this->usuarios as $u): ?>
            <tr>
                <td><?= $u['id'] ?></td>
                <td><?= $u['nombre'] ?></td>
                <td><?= $u['edad'] ?></td>
                <td><?= $u['email'] ?></td>
                <td><a href="/incregymMVC/?url=usuarios/show&id=<?= $u['id'] ?>" class="btn btn-primary btn-sm">Ver</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>