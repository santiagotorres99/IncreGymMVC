<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title><?= $title ?? 'IncreGym' ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <div class="d-flex">


        <!-- SIDEBAR -->
        <aside class="sidebar p-3 text-white">
            <img src="assets/img/logo.png" class="sidebar-logo mb-3">



            <nav class="nav flex-column mt-4">
                <a class="nav-link text-white" href="index.php?url=home/index">🏠 Inicio</a>
                <a class="nav-link text-white" href="index.php?url=usuarios/index">👤 Usuarios</a>
                <a class="nav-link text-white ms-3" href="index.php?url=usuarios/create">📝 Crear/Modificar</a>
                <a class="nav-link text-white" href="index.php?url=rutinas/index">💪 Rutinas</a>
                <a class="nav-link text-white" href="index.php?url=horarios/index">🕒 Horarios</a>
                <a class="nav-link text-white" href="index.php?url=aforo/index">👥 Aforo</a>
            </nav>


            <a href="logout.php" class="btn btn-warning w-100 mt-auto fw-bold">Cerrar sesión</a>
        </aside>


        <!-- CONTENIDO PRINCIPAL -->
        <main class="flex-fill p-4">
            <?php include $view; ?>
        </main>
    </div>
</body>

</html>