<div class="card p-4">
    <h3 class="fw-bold">💪 Rutinas</h3>
    <p class="text-muted">En esta sección podrás gestionar las rutinas de entrenamiento.</p>

    <div class="alert alert-warning mt-3">
        Esta pantalla aún no tiene funciones, solo es la vista base. Podemos añadir aquí:
        <ul>
            <li>Crear rutinas</li>
            <li>Asignarlas a usuarios</li>
            <li>Listarlas en tabla</li>
        </ul>
    </div>
</div>