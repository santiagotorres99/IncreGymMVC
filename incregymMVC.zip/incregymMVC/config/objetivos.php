<?php

return [
    "💪 Mr Increíble: Hipertrofia / Aumento de masa muscular",
    "❄️ Frozono: Tonificación",
    "⚡ Dash: Atletas (pliometría, potencia)",
    "🔥 Elastic Girl: Pérdida de grasa + Flexibilidad",
    "🟣 Violeta: Adolescentes principiantes",
    "🏋️ Jack Jack: HYROX / CROSSFIT / IRONMAN",
    "🧓 Edna Moda: Recuperación funcional / +65"
];