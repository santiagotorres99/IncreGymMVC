<?php
class Usuario {
static function all() {
return [
['id'=>1,'nombre'=>'María','edad'=>28,'email'=>'maria@example.com'],
['id'=>2,'nombre'=>'Carlos','edad'=>34,'email'=>'carlos@example.com'],
['id'=>3,'nombre'=>'Lucía','edad'=>22,'email'=>'lucia@example.com']
];
}
}
?>