<?php
session_start();
if (isset($_SESSION['user'])) {
header("Location: index.php");
exit;
}
$error = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$u = $_POST['usuario'];
$p = $_POST['password'];
if ($u === 'adminGym' && $p === '1234') {
$_SESSION['user'] = 'adminGym';
header("Location: index.php");
exit;
} else {
$error = "Usuario o contraseña incorrectos";
}
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Login - The IncreGym</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body class="login-bg">
    <div class="login-card text-center p-4">
        <img src="assets/img/logo.png" class="logo-login mb-3">
        <h2 class="login-title"><span>Bienvenido a INGREGYM</span></h2>


        <?php if ($error): ?>
        <div class="alert alert-danger py-1"><?= $error ?></div>
        <?php endif; ?>


        <form method="post" class="mt-3">
            <input type="text" name="usuario" placeholder="Usuario" class="form-control mb-3">
            <input type="password" name="password" placeholder="Contraseña" class="form-control mb-3">
            <button class="btn btn-warning w-100 fw-bold">Iniciar sesión</button>
        </form>
    </div>
</body>

</html>