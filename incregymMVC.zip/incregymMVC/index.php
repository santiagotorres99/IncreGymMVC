<?php
session_start();
if (!isset($_SESSION['user'])) {
header("Location: login.php");
exit;
}
require_once 'controllers/HomeController.php';
require_once 'controllers/UsuarioController.php';
require_once 'controllers/RutinaController.php';
require_once 'controllers/HorarioController.php';
require_once 'controllers/AforoController.php';


$url = $_GET['url'] ?? 'home/index';
$parts = explode('/', $url);
$controller = $parts[0];
$action = $parts[1] ?? 'index';


switch ($controller) {
case 'usuarios': $c = new UsuarioController(); break;
case 'rutinas': $c = new RutinaController(); break;
case 'horarios': $c = new HorarioController(); break;
case 'aforo': $c = new AforoController(); break;
default: $c = new HomeController();
}


if (method_exists($c, $action)) $c->$action(); else $c->index();